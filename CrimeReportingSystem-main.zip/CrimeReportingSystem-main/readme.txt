Create a database named "test".
Inside it, create a table named "crime_reports".

By default, all the complaints are having status as "PENDING".
If action has been taken, the admin can delete the record by clicking on  the "Resolved" button.

******To Run this project:
1. XAMPP -> Start Apache and MySql
2. open any browser -> type URL -> http://localhost/harish/CrimeReportingSystem-main/index.html