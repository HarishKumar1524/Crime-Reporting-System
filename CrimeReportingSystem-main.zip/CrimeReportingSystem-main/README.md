# CrimeReportingSystem

## Procedure to Run this project on your system:
1. Download XAMPP and start Apache and MySQL server by going in XAMPP Control Panel.
2. Copy all the files in this repository inside a folder named "CrimeReportingSystem" inside "htdocs" folder of xampp.
3. Go to this URL by typing it in any browser: localhost/CrimeReportingSystem/index.html 
4. You may navigate to the ADMIN PORTAL by clicking on Administrator Login.
5. The Username and Password for ADMIN PORTAL are admin and admin respectively.
6. Click on View Complaints to view all the complaints filed by the users.
7. Logout by clicking on logout button in the navbar.
