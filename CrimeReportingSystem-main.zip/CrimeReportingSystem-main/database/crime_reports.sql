-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2022 at 07:12 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `crime_reports`
--

CREATE TABLE `crime_reports` (
  `Report_ID` int(11) NOT NULL,
  `Name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `Age` int(3) NOT NULL,
  `Gender` varchar(1) CHARACTER SET latin1 NOT NULL,
  `Phone no.` varchar(10) CHARACTER SET latin1 NOT NULL,
  `Aadhaar no.` varchar(12) CHARACTER SET latin1 NOT NULL,
  `Crime Location` text CHARACTER SET latin1 NOT NULL,
  `Nearest_station` text CHARACTER SET latin1 NOT NULL,
  `Description` longtext CHARACTER SET latin1 NOT NULL,
  `Complaint Filing Date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crime_reports`
--

INSERT INTO `crime_reports` (`Report_ID`, `Name`, `Email`, `Age`, `Gender`, `Phone no.`, `Aadhaar no.`, `Crime Location`, `Nearest_station`, `Description`, `Complaint Filing Date`) VALUES
(1, 'prem', 'prem21@gmail.com', 22, 'M', '8515254575', '456325468546', 'rangampet', 'chandragiri', 'chain snatching', '2022-03-10 19:03:48'),
(2, 'sivareddy', 'siva514@gmail.com', 25, 'M', '8515254554', '456325468523', 'Tirupati', '1town', 'Kidnaper', '2022-03-10 19:05:53'),
(3, 'Naranya', 'narayana35@gmail.com', 25, 'M', '7979791545', '445645857865', 'mangapuram', '2town', 'theif', '2022-03-12 19:09:23'),
(4, 'Revanth', 'revanthkum21@gmail.com', 23, 'M', '8515254865', '456325467856', 'Leelamahal', 'Alipiri', 'Drug dealer', '2022-03-13 23:17:56'),
(5, 'jeswanth', 'jessi@gmail.com', 21, 'M', '9515859874', '354585854758', 'chittor', '2town', 'terrorist', '2022-03-13 23:24:45'),
(6, 'Priya', 'priya38@gmail.com', 22, 'F', '8515254227', '354585859856', 'Renigunta airport', '1town', 'murder', '2022-03-13 23:28:37'),
(7, 'kishore', 'k54719@gmail.com', 27, 'M', '9053248627', '354585486579', 'kodur', '2town', 'weapons supply illegal', '2022-03-13 23:31:11'),
(8, 'Devi', 'd1324@gmail.com', 23, 'F', '9053248648', '354585859820', 'jeevakona', 'West police station', 'Street robbery', '2022-03-13 23:33:55'),
(9, 'manoj', 'manojkumar44@gmail.com', 27, 'M', '8515254348', '456325468154', 'Tirupati', '1town', 'auto theft', '2022-03-13 23:36:04'),
(10, 'shyam', 'ss214@gmail.com', 25, 'M', '9515859458', '456325467735', 'chittor', '2town', 'murder', '2022-03-13 23:38:00'),
(12, 'usha', 'usha21@gmail.com', 27, 'F', '8515254223', '456325468524', 'Tirupati', '1town', 'Terroist', '2022-04-03 22:32:43'),
(13, 'Somesh', 'somesh2415@gmail.com', 24, 'M', '8515254268', '354585854752', 'Renigunta airport', '2town', 'Drugs supply\r\n', '2022-04-03 22:36:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crime_reports`
--
ALTER TABLE `crime_reports`
  ADD PRIMARY KEY (`Report_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crime_reports`
--
ALTER TABLE `crime_reports`
  MODIFY `Report_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
